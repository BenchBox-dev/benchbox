from __future__ import annotations

from benchbox._vendor.sqlglot.dialects.mysql import MySQL
from benchbox._vendor.sqlglot.generators.doris import DorisGenerator
from benchbox._vendor.sqlglot.parsers.doris import DorisParser


class Doris(MySQL):
    PREFER_COLUMNS_TO_ALIASES_IN_HAVING_AND_QUALIFY = False
    HAVING_ALIASES_SHADOW_UNGROUPED_COLUMNS = False
    DATE_FORMAT = "'yyyy-MM-dd'"
    DATEINT_FORMAT = "'yyyyMMdd'"
    TIME_FORMAT = "'yyyy-MM-dd HH:mm:ss'"

    class Tokenizer(MySQL.Tokenizer):
        DASH_COMMENT_REQUIRES_BOUNDARY = False
        COMMENTS_TERMINATE_AT_NEWLINE_ONLY = False

    Parser = DorisParser

    Generator = DorisGenerator
