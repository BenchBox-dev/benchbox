from __future__ import annotations

from benchbox._vendor.sqlglot import tokens
from benchbox._vendor.sqlglot.dialects.dialect import (
    Dialect,
    NormalizationStrategy,
    UsingColumnOrder,
)
from benchbox._vendor.sqlglot.generators.sqlite import SQLiteGenerator
from benchbox._vendor.sqlglot.parsers.sqlite import SQLiteParser
from benchbox._vendor.sqlglot.tokens import TokenType


class SQLite(Dialect):
    # https://sqlite.org/forum/forumpost/5e575586ac5c711b?raw
    NORMALIZATION_STRATEGY = NormalizationStrategy.CASE_INSENSITIVE
    ASCII_ONLY_NORMALIZATION = True
    TYPED_DIVISION = True
    SAFE_DIVISION = True
    PREFER_COLUMNS_TO_ALIASES_IN_HAVING_AND_QUALIFY = True
    SAFE_TO_ELIMINATE_DOUBLE_NEGATION = False
    USING_COLUMN_ORDER = UsingColumnOrder.IN_PLACE
    CONCAT_COALESCE = True
    CONCAT_WS_COALESCE = True
    INTERSECT_BINDS_TIGHTER_THAN_UNION_AND_EXCEPT = False

    class Tokenizer(tokens.Tokenizer):
        IDENTIFIERS = ['"', ("[", "]"), "`"]
        HEX_STRINGS = [("x'", "'"), ("X'", "'"), ("0x", ""), ("0X", "")]

        NESTED_COMMENTS = False
        COMMENTS_TERMINATE_AT_NEWLINE_ONLY = True

        KEYWORDS = {
            **tokens.Tokenizer.KEYWORDS,
            "ATTACH": TokenType.ATTACH,
            "DETACH": TokenType.DETACH,
            # REAL, FLOAT and DOUBLE are all 8-byte IEEE floats in SQLite (REAL affinity),
            # so they must not become a 4-byte float in dialects where REAL/FLOAT means FLOAT4
            "FLOAT": TokenType.DOUBLE,
            "INDEXED BY": TokenType.INDEXED_BY,
            "MATCH": TokenType.MATCH,
            "REAL": TokenType.DOUBLE,
        }

        KEYWORDS.pop("/*+")

        COMMANDS = {*tokens.Tokenizer.COMMANDS, TokenType.REPLACE}

    Parser = SQLiteParser

    Generator = SQLiteGenerator
