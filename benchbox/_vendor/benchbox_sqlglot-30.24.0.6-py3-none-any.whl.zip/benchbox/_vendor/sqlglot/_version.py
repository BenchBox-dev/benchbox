__version__ = '30.24.0.6'
__version_tuple__ = (30, 24, 0, 6)
