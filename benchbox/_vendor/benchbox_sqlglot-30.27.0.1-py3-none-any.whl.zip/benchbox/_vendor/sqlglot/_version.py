__version__ = '30.27.0.1'
__version_tuple__ = (30, 27, 0, 1)
