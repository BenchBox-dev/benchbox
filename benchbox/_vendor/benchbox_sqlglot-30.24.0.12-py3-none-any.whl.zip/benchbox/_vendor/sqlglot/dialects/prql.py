from __future__ import annotations

from benchbox._vendor.sqlglot import tokens
from benchbox._vendor.sqlglot.dialects.dialect import Dialect
from benchbox._vendor.sqlglot.generators.prql import PRQLGenerator
from benchbox._vendor.sqlglot.parsers.prql import PRQLParser
from benchbox._vendor.sqlglot.tokens import TokenType


class PRQL(Dialect):
    DPIPE_IS_STRING_CONCAT = False

    Generator = PRQLGenerator

    class Tokenizer(tokens.Tokenizer):
        IDENTIFIERS = ["`"]
        QUOTES = ["'", '"']

        SINGLE_TOKENS = {
            **tokens.Tokenizer.SINGLE_TOKENS,
            "=": TokenType.ALIAS,
            "'": TokenType.QUOTE,
            '"': TokenType.QUOTE,
            "`": TokenType.IDENTIFIER,
            "#": TokenType.COMMENT,
        }

        KEYWORDS = {
            **tokens.Tokenizer.KEYWORDS,
        }

    Parser = PRQLParser
