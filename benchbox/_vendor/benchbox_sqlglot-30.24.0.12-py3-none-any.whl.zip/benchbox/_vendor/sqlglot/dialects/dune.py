from __future__ import annotations


from benchbox._vendor.sqlglot.dialects.trino import Trino
from benchbox._vendor.sqlglot.generators.dune import DuneGenerator
from benchbox._vendor.sqlglot.parsers.dune import DuneParser


class Dune(Trino):
    Parser = DuneParser

    class Tokenizer(Trino.Tokenizer):
        HEX_STRINGS = ["0x", ("X'", "'")]

    Generator = DuneGenerator
