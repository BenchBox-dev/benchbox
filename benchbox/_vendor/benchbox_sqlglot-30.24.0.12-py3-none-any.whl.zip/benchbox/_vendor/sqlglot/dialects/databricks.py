from __future__ import annotations

from copy import deepcopy
from collections import defaultdict

from benchbox._vendor.sqlglot import exp
from benchbox._vendor.sqlglot.dialects.spark import Spark
from benchbox._vendor.sqlglot.generators.databricks import DatabricksGenerator
from benchbox._vendor.sqlglot.parsers.databricks import DatabricksParser
from benchbox._vendor.sqlglot.tokens import TokenType
from benchbox._vendor.sqlglot.optimizer.annotate_types import TypeAnnotator
from benchbox._vendor.sqlglot.typing.databricks import EXPRESSION_METADATA


class Databricks(Spark):
    SAFE_DIVISION = False
    COPY_PARAMS_ARE_CSV = False
    EXPRESSION_METADATA = EXPRESSION_METADATA.copy()

    COERCES_TO = defaultdict(set, deepcopy(TypeAnnotator.COERCES_TO))
    for text_type in exp.DataType.TEXT_TYPES:
        COERCES_TO[text_type] |= {
            *exp.DataType.NUMERIC_TYPES,
            *exp.DataType.TEMPORAL_TYPES,
            exp.DType.BINARY,
            exp.DType.BOOLEAN,
            exp.DType.INTERVAL,
        }

    class JSONPathTokenizer(Spark.JSONPathTokenizer):
        IDENTIFIERS = ["`", '"']

    class Tokenizer(Spark.Tokenizer):
        KEYWORDS = {
            **Spark.Tokenizer.KEYWORDS,
            "MATCH_RECOGNIZE": TokenType.MATCH_RECOGNIZE,
            "STREAM": TokenType.STREAM,
            "VOID": TokenType.VOID,
        }

    Parser = DatabricksParser

    Generator = DatabricksGenerator
