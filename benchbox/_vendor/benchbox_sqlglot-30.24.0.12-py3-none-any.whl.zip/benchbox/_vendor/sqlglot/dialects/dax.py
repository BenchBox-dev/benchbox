from __future__ import annotations

from benchbox._vendor.sqlglot import tokens
from benchbox._vendor.sqlglot.dialects.dialect import Dialect
from benchbox._vendor.sqlglot.generators.dax import DAXGenerator
from benchbox._vendor.sqlglot.parsers.dax import DAXParser


class DAX(Dialect):
    DPIPE_IS_STRING_CONCAT = False

    Generator = DAXGenerator

    class Tokenizer(tokens.Tokenizer):
        IDENTIFIERS = ["'", ("[", "]")]
        QUOTES = ['"']
        STRING_ESCAPES = ['"']
        COMMENTS = ["--", "//", ("/*", "*/")]

    Parser = DAXParser
