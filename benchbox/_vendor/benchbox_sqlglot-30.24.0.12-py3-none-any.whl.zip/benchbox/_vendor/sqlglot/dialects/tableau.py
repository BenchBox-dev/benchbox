from __future__ import annotations

from benchbox._vendor.sqlglot import tokens
from benchbox._vendor.sqlglot.dialects.dialect import Dialect
from benchbox._vendor.sqlglot.generators.tableau import TableauGenerator
from benchbox._vendor.sqlglot.parsers.tableau import TableauParser


class Tableau(Dialect):
    LOG_BASE_FIRST = False

    class Tokenizer(tokens.Tokenizer):
        IDENTIFIERS = [("[", "]")]
        QUOTES = ["'", '"']

    Generator = TableauGenerator

    Parser = TableauParser
