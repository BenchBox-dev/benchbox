from __future__ import annotations

from benchbox._vendor.sqlglot import exp, tokens
from benchbox._vendor.sqlglot.dialects.dialect import Dialect
from benchbox._vendor.sqlglot.generators.postgres import PostgresGenerator
from benchbox._vendor.sqlglot.parsers.postgres import PostgresParser
from benchbox._vendor.sqlglot.tokens import TokenType
from benchbox._vendor.sqlglot.typing.postgres import EXPRESSION_METADATA


class Postgres(Dialect):
    EXPRESSION_METADATA = EXPRESSION_METADATA.copy()
    INDEX_OFFSET = 1
    ASCII_ONLY_NORMALIZATION = True
    # Normalizing `x IS NOT NULL` to `NOT x IS NULL` is unsafe due to row values,
    # e.g. `ROW(1, NULL) IS NOT NULL` is false whereas `NOT ROW(1, NULL) IS NULL` is true
    NORMALIZE_NOT_NULL = False
    TYPED_DIVISION = True
    CONCAT_COALESCE = True
    CONCAT_WS_COALESCE = True
    NULL_ORDERING = "nulls_are_large"
    SUPPORTS_LIMIT_ALL = True
    TIME_FORMAT = "'YYYY-MM-DD HH24:MI:SS'"
    TABLESAMPLE_SIZE_IS_PERCENT = True
    TABLES_REFERENCEABLE_AS_COLUMNS = True

    DEFAULT_FUNCTIONS_COLUMN_NAMES = {
        exp.ExplodingGenerateSeries: "generate_series",
    }

    TIME_MAPPING = {
        "d": "%u",  # 1-based day of week
        "D": "%u",  # 1-based day of week
        "dd": "%d",  # day of month
        "DD": "%d",  # day of month
        "ddd": "%j",  # zero padded day of year
        "DDD": "%j",  # zero padded day of year
        "FMDD": "%-d",  # - is no leading zero for Python; same for FM in postgres
        "FMDDD": "%-j",  # day of year
        "FMHH12": "%-I",  # 9
        "FMHH24": "%-H",  # 9
        "FMMI": "%-M",  # Minute
        "FMMM": "%-m",  # 1
        "FMSS": "%-S",  # Second
        "HH12": "%I",  # 09
        "HH24": "%H",  # 09
        "iw": "%V",  # ISO 8601 week of year
        "IW": "%V",  # ISO 8601 week of year
        "iyyy": "%G",  # ISO 8601 week-numbering year
        "IYYY": "%G",  # ISO 8601 week-numbering year
        "mi": "%M",  # zero padded minute
        "MI": "%M",  # zero padded minute
        "mm": "%m",  # 01
        "MM": "%m",  # 01
        "OF": "%z",  # utc offset
        "ss": "%S",  # zero padded second
        "SS": "%S",  # zero padded second
        "TMDay": "%A",  # TM is locale dependent
        "TMDy": "%a",
        "TMMon": "%b",  # Sep
        "TMMonth": "%B",  # September
        "day": "%Aenlower",  # tuesday
        "dy": "%aenlower",  # tue
        "TZ": "%Z",  # uppercase timezone name
        "US": "%f",  # zero padded microsecond
        "ww": "%U",  # 1-based week of year
        "WW": "%U",  # 1-based week of year
        "yy": "%y",  # 15
        "YY": "%y",  # 15
        "yyy": "%Ythree",  # 015
        "YYY": "%Ythree",  # 015
        "yyyy": "%Y",  # 2015
        "YYYY": "%Y",  # 2015
    }

    UNESCAPED_SEQUENCES = {"\\a": "a"}

    class Tokenizer(tokens.Tokenizer):
        NUMERIC_ESCAPES = {
            "x": (16, 1, 2, 0xFF),
            "u": (16, 4, 4, 0xFFFF),
            "U": (16, 8, 8, 0x10FFFF),
            "0": (8, 1, 3, 0o777),
        }
        NUMERIC_ESCAPES_ARE_BYTES = True
        DROP_UNKNOWN_ESCAPES = True
        BIT_STRINGS = [("b'", "'"), ("B'", "'")]
        HEX_STRINGS = [("x'", "'"), ("X'", "'")]
        BYTE_STRINGS = [("e'", "'"), ("E'", "'")]
        UNICODE_STRINGS = [("U&'", "'"), ("u&'", "'")]
        BYTE_STRING_ESCAPES = ["'", "\\"]
        HEREDOC_STRINGS = ["$"]

        HEREDOC_TAG_IS_IDENTIFIER = True
        HEREDOC_STRING_ALTERNATIVE = TokenType.PARAMETER

        COMMANDS = {*tokens.Tokenizer.COMMANDS, TokenType.LOCK}

        KEYWORDS = {
            **tokens.Tokenizer.KEYWORDS,
            "~": TokenType.RLIKE,
            "@@": TokenType.DAT,
            "@?": TokenType.AT_QMARK,
            "@>": TokenType.AT_GT,
            "<@": TokenType.LT_AT,
            "?&": TokenType.QMARK_AMP,
            "?|": TokenType.QMARK_PIPE,
            "#-": TokenType.HASH_DASH,
            "|/": TokenType.PIPE_SLASH,
            "||/": TokenType.DPIPE_SLASH,
            "^@": TokenType.CARET_AT,
            "BEGIN": TokenType.BEGIN,
            "BIGSERIAL": TokenType.BIGSERIAL,
            "CSTRING": TokenType.PSEUDO_TYPE,
            "DECLARE": TokenType.COMMAND,
            "DO": TokenType.COMMAND,
            "EXEC": TokenType.COMMAND,
            "HSTORE": TokenType.HSTORE,
            "INT8": TokenType.BIGINT,
            "MONEY": TokenType.MONEY,
            "NAME": TokenType.NAME,
            "OID": TokenType.OBJECT_IDENTIFIER,
            "ONLY": TokenType.ONLY,
            "POINT": TokenType.POINT,
            "REFRESH": TokenType.COMMAND,
            "REINDEX": TokenType.COMMAND,
            "RESET": TokenType.COMMAND,
            "SERIAL": TokenType.SERIAL,
            "SMALLSERIAL": TokenType.SMALLSERIAL,
            "TEMP": TokenType.TEMPORARY,
            "TYPE": TokenType.TYPE,
            "REGCLASS": TokenType.OBJECT_IDENTIFIER,
            "REGCOLLATION": TokenType.OBJECT_IDENTIFIER,
            "REGCONFIG": TokenType.OBJECT_IDENTIFIER,
            "REGDICTIONARY": TokenType.OBJECT_IDENTIFIER,
            "REGNAMESPACE": TokenType.OBJECT_IDENTIFIER,
            "REGOPER": TokenType.OBJECT_IDENTIFIER,
            "REGOPERATOR": TokenType.OBJECT_IDENTIFIER,
            "REGPROC": TokenType.OBJECT_IDENTIFIER,
            "REGPROCEDURE": TokenType.OBJECT_IDENTIFIER,
            "REGROLE": TokenType.OBJECT_IDENTIFIER,
            "REGTYPE": TokenType.OBJECT_IDENTIFIER,
            "FLOAT": TokenType.DOUBLE,
            "XML": TokenType.XML,
            "VARIADIC": TokenType.VARIADIC,
            "INOUT": TokenType.INOUT,
        }
        KEYWORDS.pop("/*+")
        KEYWORDS.pop("DIV")

        SINGLE_TOKENS = {
            **tokens.Tokenizer.SINGLE_TOKENS,
            "$": TokenType.HEREDOC_STRING,
        }

        VAR_SINGLE_TOKENS = {"$"}

    Parser = PostgresParser

    Generator = PostgresGenerator
