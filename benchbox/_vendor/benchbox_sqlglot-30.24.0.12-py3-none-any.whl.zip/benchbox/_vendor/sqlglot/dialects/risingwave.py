from __future__ import annotations

from benchbox._vendor.sqlglot.dialects.postgres import Postgres
from benchbox._vendor.sqlglot.generators.risingwave import RisingWaveGenerator
from benchbox._vendor.sqlglot.parsers.risingwave import RisingWaveParser
from benchbox._vendor.sqlglot.tokens import TokenType


class RisingWave(Postgres):
    NORMALIZE_NOT_NULL = True

    REQUIRES_PARENTHESIZED_STRUCT_ACCESS = True
    SUPPORTS_STRUCT_STAR_EXPANSION = True

    UNESCAPED_SEQUENCES = {"\\a": "a", "\\v": "v"}

    class Tokenizer(Postgres.Tokenizer):
        KEYWORDS = {
            **Postgres.Tokenizer.KEYWORDS,
            "SINK": TokenType.SINK,
            "SOURCE": TokenType.SOURCE,
        }

    Parser = RisingWaveParser

    Generator = RisingWaveGenerator
