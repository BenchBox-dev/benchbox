from benchbox._vendor.sqlglot.dialects.dialect import Dialect
from benchbox._vendor.sqlglot.generators.druid import DruidGenerator
from benchbox._vendor.sqlglot.parsers.druid import DruidParser


class Druid(Dialect):
    Parser = DruidParser

    Generator = DruidGenerator
