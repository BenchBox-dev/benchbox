from __future__ import annotations

import string
import typing as t

from benchbox._vendor.sqlglot import exp, tokens
from benchbox._vendor.sqlglot.dialects.dialect import (
    Dialect,
    NormalizationStrategy,
)
from benchbox._vendor.sqlglot.generators.oracle import OracleGenerator
from benchbox._vendor.sqlglot.parsers.oracle import OracleParser
from benchbox._vendor.sqlglot.tokens import TokenType


class Oracle(Dialect):
    ALIAS_POST_TABLESAMPLE = True
    LOCKING_READS_SUPPORTED = True
    TABLESAMPLE_SIZE_IS_PERCENT = True
    NULL_ORDERING = "nulls_are_large"
    ON_CONDITION_EMPTY_BEFORE_ERROR = False
    ALTER_TABLE_ADD_REQUIRED_FOR_EACH_COLUMN = False
    DISABLES_ALIAS_REF_EXPANSION = True

    # See section 8: https://docs.oracle.com/cd/A97630_01/server.920/a96540/sql_elements9a.htm
    NORMALIZATION_STRATEGY = NormalizationStrategy.UPPERCASE

    # https://docs.oracle.com/database/121/SQLRF/sql_elements004.htm#SQLRF00212
    # https://docs.python.org/3/library/datetime.html#strftime-and-strptime-format-codes
    TIME_MAPPING = {
        "D": "%u",  # Day of week (1-7)
        "DAY": "%A",  # name of day
        "DD": "%d",  # day of month (1-31)
        "DDD": "%j",  # day of year (1-366)
        "DY": "%a",  # abbreviated name of day
        "HH": "%I",  # Hour of day (1-12)
        "HH12": "%I",  # alias for HH
        "HH24": "%H",  # Hour of day (0-23)
        "IW": "%V",  # Calendar week of year (1-52 or 1-53), as defined by the ISO 8601 standard
        "IYYY": "%G",  # 4-digit year of the ISO 8601 week-numbering calendar
        "MI": "%M",  # Minute (0-59)
        "MM": "%m",  # Month (01-12; January = 01)
        "MON": "%b",  # Abbreviated name of month
        "MONTH": "%B",  # Name of month
        "SS": "%S",  # Second (0-59)
        "WW": "%W",  # Week of year (1-53)
        "YY": "%y",  # 15
        "YYYY": "%Y",  # 2015
        "FF6": "%f",  # only 6 digits are supported in python formats
    }

    PSEUDOCOLUMNS = {"ROWNUM", "ROWID", "OBJECT_ID", "OBJECT_VALUE", "LEVEL"}

    def can_quote(self, identifier: exp.Identifier, identify: str | bool = "safe") -> bool:
        # Disable quoting for pseudocolumns as it may break queries e.g
        # `WHERE "ROWNUM" = ...` does not work but `WHERE ROWNUM = ...` does
        return (
            identifier.quoted or not isinstance(identifier.parent, exp.Pseudocolumn)
        ) and super().can_quote(identifier, identify=identify)

    class Tokenizer(tokens.Tokenizer):
        VAR_SINGLE_TOKENS = {"@", "$", "#"}

        UNICODE_STRINGS = [
            (prefix + q, q)
            for q in t.cast(list[str], tokens.Tokenizer.QUOTES)
            for prefix in ("U", "u")
        ]

        # https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/Literals.html
        # Alternative quoting, e.g. q'[it's]': the delimiters are part of the quote, so the
        # text in between is taken as is, without escapes
        RAW_STRINGS = [
            (f"{prefix}'{start}", f"{end}'")
            for prefix in ("q", "Q")
            for start, end in (
                ("[", "]"),
                ("{", "}"),
                ("(", ")"),
                ("<", ">"),
                *(
                    (c, c)
                    for c in string.ascii_letters + string.digits + string.punctuation
                    if c not in "[{(<"
                ),
            )
        ]
        NATIONAL_RAW_STRINGS = [
            (prefix + start, end)
            for start, end in t.cast(list[tuple[str, str]], RAW_STRINGS)
            for prefix in ("n", "N")
        ]
        STRING_ESCAPES_ALLOWED_IN_RAW_STRINGS = False

        NESTED_COMMENTS = False

        KEYWORDS = {
            **tokens.Tokenizer.KEYWORDS,
            "(+)": TokenType.JOIN_MARKER,
            # https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/Comparison-Conditions.html
            "^=": TokenType.NEQ,
            "BINARY_DOUBLE": TokenType.DOUBLE,
            "BINARY_FLOAT": TokenType.FLOAT,
            "BULK COLLECT INTO": TokenType.BULK_COLLECT_INTO,
            "COLUMNS": TokenType.COLUMN,
            "MATCH_RECOGNIZE": TokenType.MATCH_RECOGNIZE,
            "MINUS": TokenType.EXCEPT,
            "NVARCHAR2": TokenType.NVARCHAR,
            "ORDER SIBLINGS BY": TokenType.ORDER_SIBLINGS_BY,
            "SAMPLE": TokenType.TABLE_SAMPLE,
            "START": TokenType.BEGIN,
            "SUBPARTITION": TokenType.PARTITION,
            "TOP": TokenType.TOP,
            "VARCHAR2": TokenType.VARCHAR,
            "SYSTIMESTAMP": TokenType.SYSTIMESTAMP,
        }

    Parser = OracleParser

    Generator = OracleGenerator
