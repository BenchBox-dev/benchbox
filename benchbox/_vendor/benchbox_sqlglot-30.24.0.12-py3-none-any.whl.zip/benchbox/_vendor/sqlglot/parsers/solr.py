from __future__ import annotations

from benchbox._vendor.sqlglot import exp, parser
from benchbox._vendor.sqlglot.tokens import TokenType


class SolrParser(parser.Parser):
    TABLE_ALIAS_TOKENS = parser.Parser.TABLE_ALIAS_TOKENS | {
        TokenType.ANTI,
        TokenType.SEMI,
    }

    DISJUNCTION = {
        **parser.Parser.DISJUNCTION,
        TokenType.DPIPE: exp.Or,
    }
