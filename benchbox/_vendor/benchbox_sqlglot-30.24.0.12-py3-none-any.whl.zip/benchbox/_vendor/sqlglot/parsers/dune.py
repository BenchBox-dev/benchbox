from __future__ import annotations

from benchbox._vendor.sqlglot.parsers.trino import TrinoParser


class DuneParser(TrinoParser):
    pass
