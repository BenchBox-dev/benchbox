from __future__ import annotations

from benchbox._vendor.sqlglot.parsers.postgres import PostgresParser


class QuestDBParser(PostgresParser):
    pass
