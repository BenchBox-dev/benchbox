from __future__ import annotations

import typing as t

from benchbox._vendor.sqlglot.optimizer.journal import Journal, record
from benchbox._vendor.sqlglot.optimizer.scope import Scope, build_scope


if t.TYPE_CHECKING:
    from benchbox._vendor.sqlglot._typing import E


def eliminate_ctes(expression: E, journal: Journal | None = None) -> E:
    '\n    Remove unused CTEs from an expression.\n\n    Example:\n        >>> import benchbox._vendor.sqlglot as sqlglot\n        >>> sql = "WITH y AS (SELECT a FROM x) SELECT a FROM z"\n        >>> expression = sqlglot.parse_one(sql)\n        >>> eliminate_ctes(expression).sql()\n        \'SELECT a FROM z\'\n\n    Args:\n        expression (sqlglot.Expr): expression to optimize\n    Returns:\n        sqlglot.Expr: optimized expression\n    '
    root = build_scope(expression)

    if root:
        ref_count = root.ref_count()

        # Traverse the scope tree in reverse so we can remove chains of unused CTEs
        for scope in reversed(list(root.traverse())):
            if scope.is_cte:
                count = ref_count[id(scope)]
                if count <= 0:
                    cte_node = scope.expression.parent
                    if not cte_node:
                        continue
                    with_node = cte_node.parent
                    if journal is not None and with_node:
                        record(journal, with_node, "expressions")
                    cte_node.pop()

                    # Pop the entire WITH clause if this is the last CTE
                    if with_node and len(with_node.expressions) <= 0:
                        if journal is not None and with_node.parent:
                            record(journal, with_node.parent, "with_")
                        with_node.pop()

                    # Decrement the ref count for all sources this CTE selects from
                    for _, source in scope.selected_sources.values():
                        if isinstance(source, Scope):
                            ref_count[id(source)] -= 1

    return expression
