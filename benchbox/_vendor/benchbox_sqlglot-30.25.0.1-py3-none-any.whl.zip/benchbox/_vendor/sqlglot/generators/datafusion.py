from __future__ import annotations

from benchbox._vendor.sqlglot import exp
from benchbox._vendor.sqlglot.benchbox.date_literals import DateLiteralPadding
from benchbox._vendor.sqlglot.generators.postgres import PostgresGenerator


class DataFusionGenerator(DateLiteralPadding, PostgresGenerator):
    PAD_DATE_LITERALS = False
    SUPPORTS_EMPTY_GROUP_BY = False
    EXACT_DIVISION_TYPE = exp.DType.DOUBLE
