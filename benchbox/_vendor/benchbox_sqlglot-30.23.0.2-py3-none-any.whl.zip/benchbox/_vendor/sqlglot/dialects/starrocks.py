from __future__ import annotations

from benchbox._vendor.sqlglot import exp
from benchbox._vendor.sqlglot.dialects.dialect import UsingColumnOrder
from benchbox._vendor.sqlglot.dialects.mysql import MySQL
from benchbox._vendor.sqlglot.generators.starrocks import StarRocksGenerator
from benchbox._vendor.sqlglot.parsers.starrocks import StarRocksParser
from benchbox._vendor.sqlglot.tokens import TokenType


class StarRocks(MySQL):
    STRICT_JSON_PATH_SYNTAX = False
    INDEX_OFFSET = 1
    USING_COLUMN_ORDER = UsingColumnOrder.USING_LIST

    DEFAULT_FUNCTIONS_COLUMN_NAMES = {
        exp.GenerateSeries: "generate_series",
    }

    class Tokenizer(MySQL.Tokenizer):
        DASH_COMMENT_REQUIRES_BOUNDARY = False
        COMMENTS_TERMINATE_AT_NEWLINE_ONLY = False

        KEYWORDS = {
            **MySQL.Tokenizer.KEYWORDS,
            "HLL": TokenType.HLLSKETCH,
            "LARGEINT": TokenType.INT128,
            "REFRESH": TokenType.REFRESH,
        }
        KEYWORDS.pop("IGNORE")

    Parser = StarRocksParser

    Generator = StarRocksGenerator
