__version__ = '30.25.0.2'
__version_tuple__ = (30, 25, 0, 2)
