__version__ = '30.35.0.5'
__version_tuple__ = (30, 35, 0, 5)
